﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    class Program
    {

        delegate void DemoDelegate(string s);
        delegate string DemoDelegate2();

        static void Main(string[] args)
        {
            WriteSomething(Demo);
        }

        static void WriteSomething(Func<string, int> method)
        {

        }

        static int Demo(string a)
        {
            Console.WriteLine("Salam demo metoddan!");
            return 5;
        }

        #region StringBuilder
        //static string ConcatStrings(params string[] words)
        //{
        //    StringBuilder result = new StringBuilder();

        //    foreach (var word in words)
        //    {
        //        result.Append(word);
        //    }

        //    return result.ToString();
        //}
        #endregion

    }
}
