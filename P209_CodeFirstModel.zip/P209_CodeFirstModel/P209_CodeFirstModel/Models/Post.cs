﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace P209_CodeFirstModel.Models
{
    public class Post
    {
        public int Id { get; set; }

        [StringLength(100)]
        [Required(ErrorMessage = "Postun başlığı doldurulmalıdır")]
        [MinLength(3)]
        public string Title { get; set; }

        [StringLength(500)]
        [Required]
        [MinLength(3)]
        public string Content { get; set; }

        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        [StringLength(100)]
        public string Author { get; set; }

        [StringLength(300)]
        public string Image { get; set; }

        [NotMapped]
        public HttpPostedFileBase Photo { get; set; }
    }
}