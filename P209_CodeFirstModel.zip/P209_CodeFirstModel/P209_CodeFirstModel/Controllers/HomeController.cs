﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P209_CodeFirstModel.DAL;
using P209_CodeFirstModel.Models;

namespace P209_CodeFirstModel.Controllers
{
    public class HomeController : Controller
    {

        private readonly BlogContext _context;

        public HomeController()
        {
            _context = new BlogContext();
        }

        public ActionResult Index()
        {
            return View(_context.Posts.ToList());
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Title, Photo, Content")]Post post)
        {
            if (!ModelState.IsValid)
            {
                return View(post);
            }

            //save photo
            post.CreatedAt = post.UpdatedAt = DateTime.Now;

            _context.Posts.Add(post);
            _context.SaveChanges();

            return RedirectToAction(nameof(Index));
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}