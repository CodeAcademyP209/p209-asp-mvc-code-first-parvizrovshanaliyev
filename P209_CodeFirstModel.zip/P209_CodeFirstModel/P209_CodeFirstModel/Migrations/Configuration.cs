namespace P209_CodeFirstModel.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using P209_CodeFirstModel.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<P209_CodeFirstModel.DAL.BlogContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(P209_CodeFirstModel.DAL.BlogContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.

            context.Posts.AddOrUpdate(
                p => new { p.Title, p.Content },
                new Post {
                    Title = "Post 3",
                    Content = "Post 1 content",
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now,
                    Author = "Semed Qasim"
                }
            );
            context.Posts.AddOrUpdate(
                p => new { p.Title, p.Content },
                new Post
                {
                    Title = "Post 2",
                    Content = "Post 2 content",
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                }
            );

            context.SaveChanges();
        }
    }
}
